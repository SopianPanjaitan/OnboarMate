# Security Design — OnboardMate

## 1. Security principles
- Least privilege.
- Deny by default.
- Server-side authorization.
- Tenant isolation.
- Private-by-default document storage.
- Secrets never shipped to the browser.
- Audit sensitive administrative operations.
- Treat user prompts and uploaded documents as untrusted input.

## 2. Authentication
- Use Supabase Auth.
- No public sign-up.
- HR-managed invitation or account provisioning.
- Secure invitation callback and session handling.
- Use server-side session verification for protected operations.
- Provide logout and password recovery flows.
- Avoid exposing whether arbitrary emails belong to an account where this could create account enumeration risk.

## 3. Authorization
- Roles are organization-scoped through organization_members.
- Employee: own profile, tasks, progress, conversations, and authorized documents.
- Mentor: explicitly assigned mentees only.
- HR Admin: organization-scoped HR operations.
- Platform Super Admin: tightly restricted platform operations.
- Enforce permissions in server services and database RLS; hiding a UI button is not authorization.

## 4. Tenant isolation
- Every tenant-owned row has organization_id or a securely enforced parent relationship.
- Derive organization context from authenticated membership, not client-supplied IDs.
- Apply RLS to all tenant-scoped tables.
- Vector retrieval must include organization, publication, and audience filters.
- Test attempts to access another organization's records and documents.

## 5. Storage
- Use private buckets for internal documents.
- Authorize upload/download through server checks or short-lived signed URLs.
- Validate extension, MIME type, file size, and file signature where practical.
- Generate storage paths server-side with organization/document identifiers.
- Do not trust filenames supplied by the browser.
- Prevent public listing and public read access.

## 6. Secrets and configuration
- Keep service-role credentials and LLM keys server-side only.
- Commit `.env.example` with placeholders, never real secrets.
- Ensure `.env*` secrets are ignored by Git.
- Use separate credentials for local, staging, and production environments.
- Rotate any credential accidentally exposed.

## 7. AI-specific threats
- Prompt injection in user messages and retrieved documents.
- Retrieval of HR-only or cross-tenant content.
- Model-generated tool arguments attempting to change user/organization identity.
- Fabricated citations.
- Excessive context disclosure.
- Unsafe file uploads and malicious document content.

Mitigations:
- Retrieved text is data, never system instruction.
- Apply authorization before retrieval and again before source display.
- Server derives user and tenant identity.
- Allowlist tools and validate arguments.
- Validate citations against retrieved chunk IDs.
- Limit file types, size, chunk count, and model context.
- Do not expose internal prompts, secrets, or raw database records.

## 8. Audit logging
Record at minimum:
- Invitation created, revoked, accepted.
- Employee role/department changes.
- Document upload, publish, archive, delete, and reprocess.
- Onboarding template changes and assignments.
- Sensitive administrative settings changes.

Do not store passwords, access tokens, raw invitation tokens, or unnecessary sensitive personal data in audit metadata.

## 9. Required security tests
- Unauthenticated request to protected route.
- Employee accessing HR route.
- Employee reading another employee's progress.
- Mentor accessing an unassigned employee.
- HR Admin accessing another organization.
- Employee retrieving HR-only document chunks.
- User attempting to submit a forged organization_id.
- Public access to private storage object.
- Service-role secret absent from client bundle.
- Prompt injection inside an uploaded document.
