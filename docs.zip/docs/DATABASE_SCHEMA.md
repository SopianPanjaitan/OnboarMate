# Database Schema — OnboardMate

## 1. Conventions
- PostgreSQL with UUID primary keys.
- `created_at` and `updated_at` timestamps where relevant.
- Tenant-owned records include `organization_id` directly or inherit it through a parent with equivalent RLS enforcement.
- Use foreign keys, indexes, unique constraints, and check constraints.
- `profiles.id` references the authentication user ID.
- Membership role is organization-scoped; do not store one global role on the profile as the source of authorization truth.

## 2. Core tables

### organizations
- `id UUID PK`
- `name TEXT NOT NULL`
- `slug TEXT UNIQUE NOT NULL`
- `description TEXT`
- `status TEXT NOT NULL`
- `created_at`, `updated_at`

### profiles
- `id UUID PK REFERENCES auth.users(id)`
- `full_name TEXT`
- `avatar_path TEXT`
- `job_title TEXT`
- `created_at`, `updated_at`

### departments
- `id UUID PK`
- `organization_id UUID FK`
- `name TEXT NOT NULL`
- `created_at`, `updated_at`
- Unique `(organization_id, name)`

### organization_members
- `id UUID PK`
- `organization_id UUID FK`
- `user_id UUID FK REFERENCES profiles(id)`
- `department_id UUID NULL FK`
- `role TEXT CHECK IN ('hr_admin','employee','mentor')`
- `status TEXT CHECK IN ('invited','active','suspended')`
- `created_at`, `updated_at`
- Unique `(organization_id, user_id)`

### invitations
- `id UUID PK`
- `organization_id UUID FK`
- `email TEXT NOT NULL`
- `role TEXT CHECK IN ('employee','mentor')`
- `department_id UUID NULL FK`
- `invited_by UUID FK`
- `auth_invitation_reference TEXT NULL`
- `status TEXT CHECK IN ('pending','accepted','expired','revoked')`
- `expires_at TIMESTAMPTZ`
- `created_at`, `updated_at`
- Add an index on normalized email and organization.
- Do not store raw invitation tokens.

### onboarding_templates
- `id UUID PK`
- `organization_id UUID FK`
- `name TEXT NOT NULL`
- `description TEXT`
- `is_active BOOLEAN DEFAULT TRUE`
- `created_by UUID FK`
- `created_at`, `updated_at`

### template_tasks
- `id UUID PK`
- `template_id UUID FK`
- `title TEXT NOT NULL`
- `description TEXT`
- `stage TEXT`
- `sort_order INTEGER`
- `due_offset_days INTEGER NULL`
- `is_required BOOLEAN DEFAULT TRUE`
- `created_at`, `updated_at`

### onboarding_assignments
- `id UUID PK`
- `organization_id UUID FK`
- `template_id UUID FK`
- `employee_user_id UUID FK`
- `assigned_by UUID FK`
- `start_date DATE`
- `status TEXT CHECK IN ('not_started','in_progress','completed','cancelled')`
- `created_at`, `updated_at`

### task_progress
- `id UUID PK`
- `organization_id UUID FK`
- `assignment_id UUID FK`
- `template_task_id UUID FK`
- `status TEXT CHECK IN ('pending','in_progress','completed','blocked')`
- `completed_at TIMESTAMPTZ NULL`
- `completed_by UUID NULL FK`
- `notes TEXT NULL`
- `created_at`, `updated_at`
- Unique `(assignment_id, template_task_id)`

### knowledge_documents
- `id UUID PK`
- `organization_id UUID FK`
- `title TEXT NOT NULL`
- `description TEXT`
- `storage_path TEXT NOT NULL`
- `file_name TEXT NOT NULL`
- `mime_type TEXT NOT NULL`
- `file_size_bytes BIGINT NOT NULL`
- `category TEXT`
- `status TEXT CHECK IN ('uploaded','processing','indexed','failed','archived')`
- `audience TEXT CHECK IN ('all_employees','hr_only','mentors_and_employees','selected_roles')`
- `is_published BOOLEAN DEFAULT FALSE`
- `version INTEGER DEFAULT 1`
- `uploaded_by UUID FK`
- `created_at`, `updated_at`

### document_chunks
- `id UUID PK`
- `organization_id UUID FK`
- `document_id UUID FK`
- `chunk_index INTEGER NOT NULL`
- `content TEXT NOT NULL`
- `embedding VECTOR(N)` where N is fixed after the embedding model is selected
- `page_number INTEGER NULL`
- `metadata JSONB`
- `embedding_model TEXT NOT NULL`
- `created_at`
- Unique `(document_id, chunk_index)`

### conversations
- `id UUID PK`
- `organization_id UUID FK`
- `user_id UUID FK`
- `title TEXT`
- `created_at`, `updated_at`

### messages
- `id UUID PK`
- `organization_id UUID FK`
- `conversation_id UUID FK`
- `role TEXT CHECK IN ('user','assistant','tool')`
- `content TEXT NOT NULL`
- `citations JSONB`
- `provider_name TEXT NULL`
- `model_name TEXT NULL`
- `created_at`

### audit_logs
- `id UUID PK`
- `organization_id UUID NULL`
- `actor_user_id UUID NULL`
- `action TEXT NOT NULL`
- `resource_type TEXT`
- `resource_id UUID NULL`
- `metadata JSONB`
- `created_at`

## 3. Relationships
- Organization has many departments, members, templates, documents, assignments, and conversations.
- Profile can belong to multiple organizations through organization_members.
- Template has many template_tasks.
- Employee has many onboarding_assignments.
- Assignment has many task_progress rows.
- Knowledge document has many document_chunks.
- Conversation has many messages.

## 4. Indexes
- `organization_members(organization_id, user_id)` unique.
- `departments(organization_id, name)` unique.
- `onboarding_assignments(organization_id, employee_user_id, status)`.
- `task_progress(assignment_id, status)`.
- `knowledge_documents(organization_id, status, is_published)`.
- `document_chunks(document_id, chunk_index)` unique.
- `conversations(organization_id, user_id, updated_at DESC)`.
- Vector index appropriate to selected pgvector operator and embedding dimension.

## 5. RLS policy principles
- Enable RLS on every tenant-scoped table.
- Resolve organization membership from the authenticated user and `organization_members`.
- Employee reads only their own profile, assignments, task progress, and conversations.
- HR Admin reads/manages records only within organizations where they have active `hr_admin` membership.
- Mentor reads only explicitly assigned mentee records; do not grant organization-wide employee visibility.
- Knowledge retrieval requires same organization, published status, and matching audience/role.
- `document_chunks` access must inherit document authorization; never rely only on a client filter.
- Invitations are visible/manageable only to authorized HR Admins in the same organization.
- Audit logs are not editable by ordinary users.
- Service-role operations must still perform explicit application-level authorization and must remain server-only.

## 6. Migration notes
- Confirm the embedding model and dimension before creating the final vector column/index.
- Changing embedding model requires re-embedding chunks; changing dimension may require a schema/index migration.
- Use migrations for all schema changes. Do not make undocumented manual production changes.
